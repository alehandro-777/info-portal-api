const Entity = require('../models/parameter')
const BaseController = require('./base-controller')

//class NewController extends BaseController {

module.exports = new BaseController(Entity);
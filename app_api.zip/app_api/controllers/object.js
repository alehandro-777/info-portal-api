const Entity = require('../models/object')
const BaseController = require('./base-controller')

//class NewController extends BaseController {

module.exports = new BaseController(Entity);